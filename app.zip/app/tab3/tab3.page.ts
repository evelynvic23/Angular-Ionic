import { Component } from '@angular/core';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {


  constructor() {}

    progressValue: number = 0;

    ngOnInit() {
      // Simule o progresso carregando a cada 1 segundo (1000 ms)
      const interval = setInterval(() => {
        this.progressValue += 0.1; // Aumente o progresso em 10% a cada segundo

        if (this.progressValue >= 1) {
          clearInterval(interval); // Pare o intervalo quando o progresso atingir 100%
        }
      }, 500);
    }

}
